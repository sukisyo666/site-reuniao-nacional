# Reunião Nacional de Vigilância Epidemiológica das Doenças de Transmissão Hídrica e Alimentar (DTHA)
## Design System

Institutional visual identity for the **Reunião Nacional de Vigilância Epidemiológica das Doenças de Transmissão Hídrica e Alimentar**, an event of the Brazilian Ministry of Health (Secretaria de Vigilância em Saúde e Ambiente / SUS).

**Personality:** Institucional · Científica · Conectada. Public-sector, scientific, contemporary — a digital extension of the event's printed identity, never a commercial landing page.

### Sources used
- Six reference artworks supplied by the user: `uploads/1.png` … `uploads/6.png` (event cover, vertical banners, symbol sheet, wave grafismo band). All brand assets in `/assets` were programmatically cropped and background-keyed from these files — nothing was redrawn.
- A written art-direction brief ("DIREÇÃO DE ARTE", 21 sections) provided in chat: palette, type scale, spacing, grafismos, iconography, motion, data-viz and accessibility rules. Its consolidated `:root` token block is the source of truth for `/tokens`.
- No codebase, Figma file or font binaries were provided. See **Substitutions & gaps**.

### Index
| Path | What it is |
| --- | --- |
| `styles.css` | Global entry point — `@import` list only. Consumers link this one file. |
| `tokens/` | `fonts · colors · typography · spacing · borders · motion · layout · base` |
| `assets/` | Logos, thematic icons, Brazil network map, line grafismos (all extracted from the reference art) |
| `components/core/` | `Button` `Badge` `Card` `Divider` |
| `components/brand/` | `TitleLockup` `IconCircle` `InstitutionalLogo` `BrasilNetworkMap` `DiagonalGraphic` |
| `components/data/` | `StatFigure` `BarChart` |
| `components/forms/` | `Input` `Select` `Checkbox` |
| `components/navigation/` | `NavBar` `SectionHeader` |
| `guidelines/` | 20 foundation specimen cards (Colors · Type · Spacing · Brand) |
| `ui_kits/site-reuniao/` | Click-through recreation of the event site (hero, programação, eixos + dados, inscrição, rodapé) |
| `templates/abertura-institucional/` | Starting template: the institutional cover page |
| `SKILL.md` | Agent-Skills wrapper for use outside this project |

---

## VISUAL FOUNDATIONS

### Colour
Deep institutional navy `#143353` carries **75–90% of every surface**; `#0D2944` for deeper bands and headers. Cyan `#36ACC1` and turquoise `#14A99F` are accents only (**5–12%**), green `#159447` / `#138871` marks Brazilian identity and event tags (**2–8%**), white is reserved for typography, logos and contrast. The Brazilian flag appears as an **official graphic element**, never recoloured or rebuilt from palette colours.

Forbidden: brown, beige, orange, pink, purple, and any multi-colour gradient.

### Type
Two families. **Barlow Condensed** (700/800) for display: tall, condensed, heavy, uppercase, leading 0.90–0.95, tracking −0.02em. **Montserrat** (300–700) for everything else: subtitles in uppercase weight 400 with 0.04–0.08em tracking, body at 1.4–1.5 leading. Chromatic emphasis is reserved for genuinely important terms — the pattern is `HÍDRICA | ALIMENTAR`, cyan and turquoise, never a coloured full title.

### Layout & space
12 columns, max 1200–1280px, gutter 24px, page padding 48px desktop / 32 tablet / 20 mobile. Composition is **vertical and deliberately empty**: identificação → grande título → subtítulo → símbolos → conteúdo → grafismo. Sections are separated by 96–160px; logo to title 48–64px; title to subtitle 16–24px. The layout must not try to fill the screen — the void is part of the identity.

### Backgrounds & grafismos
Never photographic by default. Every institutional surface carries a **line-field grafismo** — thin 2–4px strokes in `#2A637F` at 60–90% opacity forming large diagonals, wide curves and gradual overlaps, anchored to a bottom corner or the full bottom edge. Three shipped variants: descending diagonals, ascending diagonals, horizontal wave band. Random lines, dense patterns over content, and decorative geometry are out.

The **Brazil network map** (nodes + thin connections) is the central graphic: base blue/cyan, nodes in cyan/turquoise/teal-green, varied dot sizes. No 3D, no political map, no colour excess.

### Cards, borders, radii, shadows
Cards: `rgba(255,255,255,.04)` fill, `1px solid rgba(78,181,181,.25)` border, radius 0–8px (4px default), padding 24–32px, **no shadow**. Emphasis is a `3px` cyan left bar or a `3px` turquoise top bar. Borders (1/2/3px in `#2A637F`, `#36ACC1`, `#14A99F`, `rgba(255,255,255,.25)`) exist for structure, not decoration. Aesthetic is flat: `box-shadow:none` by default, `0 8px 24px rgba(0,0,0,.12)` only for exceptional elevation. Radius `999px` is never the default — buttons stay 2–4px rectangles, circles only for icon rings and map nodes.

### States
Hover lightens rather than shifts hue: primary button `#14A99F → #138871`, card fill `.04 → .07` white, ghost link cyan → teal, nav item gains a 2px cyan underline. Focus swaps the field border to teal `#4EB5B5`; error swaps it to cyan and adds a message (colour never carries meaning alone). Disabled is 42% opacity. Press states darken; nothing scales or bounces.

### Transparency & blur
White at 4–7% for surfaces, 14–25% for lines, 52–72% for secondary text. No backdrop blur, no glassmorphism, no glow.

### Motion
Discreet, functional, sober. Entrance: `opacity 0→1` + `translateY(16px→0)`, 500ms, `cubic-bezier(.22,1,.36,1)`; titles 600ms with 20px. Icons sequence at 0 / 100 / 200ms with `scale(.95→1)`. The map reveals over 800–1200ms with `scale(.96→1)` and may animate `stroke-dashoffset` on its connections. Grafismos may parallax ±5–20px on scroll. No typewriter effects; institutional content, logos and text never float.

### Imagery
Graphic elements outrank photography. When photography is used it must be documentary: public health, território brasileiro, health professionals, surveillance, laboratory, water and food when pertinent. Cool, neutral treatment. Never advertising imagery, corporate poses, cinematic grading, or filters that break the institutional palette.

### Data
Charts sit on the navy surface: grid `#2A637F`, primary series `#36ACC1`, secondary `#14A99F`, highlight `#4EB5B5`, labels white. Headline indicators use a large condensed figure (42–64px Barlow Condensed Bold) with a small unit and a 14–16px Montserrat description.

---

## CONTENT FUNDAMENTALS

- **Language:** Brazilian Portuguese, formal but plain. Technical vocabulary of epidemiological surveillance is used precisely (surto, notificação, veículo de transmissão, oportunidade do resultado, rede laboratorial).
- **Voice:** institutional third person and impersonal constructions — "A reunião nacional articula estados, municípios e laboratórios", "As vagas presenciais são destinadas às equipes de vigilância". Avoid "nós" and avoid marketing "você" except in direct form instructions ("Digite seu nome", "Concordo com o tratamento dos meus dados").
- **Casing:** display titles and subtitles in CAPS (`VIGILÂNCIA EPIDEMIOLÓGICA`, `DAS DOENÇAS DE TRANSMISSÃO`); eyebrows, badges, nav items, captions in uppercase with wide tracking; body copy in sentence case with full diacritics — never strip accents.
- **Titles** are noun phrases, two or three words per line, no verbs, no punctuation: "Panorama nacional das DTHA", "Rede laboratorial", "Encaminhamentos e pactuação". Sessions are numbered institutionally: "Painel 02", "Eixo 03", "Dia 01 · 14/10".
- **Numbers:** pt-BR formatting — comma decimal, dot thousands (`42,9%`, `1.284 surtos`). Dates as "14 a 16 de outubro de 2026"; times as "09h00".
- **Attribution** always names the institution: "Secretaria de Vigilância em Saúde e Ambiente", "Ministério da Saúde".
- **No emoji, no exclamation marks, no superlatives.** Calls to action are short and administrative: "Inscreva-se", "Ver programação", "Baixar material", "Enviar inscrição".

---

## ICONOGRAPHY

The system has **three official thematic symbols**, all extracted as PNGs from the supplied artwork and shipped in `/assets`:

| Asset | Meaning |
| --- | --- |
| `icone-gota-agua.png` | 01 — Água · transmissão hídrica |
| `icone-garfo-faca.png` | 02 — Alimentação · transmissão alimentar |
| `icone-microscopio.png` | 03 — Ciência · investigação, laboratório, vigilância |

Style: line icons, 3–5px stroke, rounded terminals, no fill, each inside a thin 2–3px circle at 50% radius. Colours limited to `#36ACC1`, `#14A99F`, `#4EB5B5`. **Solid icons and emoji are prohibited.** There is no icon font and no vendor icon set in the source material — the identity uses exactly these three marks plus the institutional logos.

UI affordances that need a glyph (chevrons, close, arrows) are drawn with CSS borders/rules in the components rather than importing a third-party set; if a broader UI set becomes necessary, choose a 2px-stroke outline family (e.g. Lucide via CDN) and flag it as a substitution — it is not part of the source identity.

Institutional marks, also extracted, never modified: `logo-sus-ms-brasil-horizontal.png`, `logo-sus-ms-brasil-vertical.png` (SUS + Ministério da Saúde + bandeira). Clearspace 24px minimum, 32px preferred, 32–48px between marks. The event's own typographic lockups are additionally shipped as raster references: `lockup-titulo-centralizado.png`, `lockup-titulo-alinhado-esquerda.png`.

---

## Substitutions & gaps (please review)

1. **Fonts are Google Fonts, not vendor files.** No binaries were supplied; `tokens/fonts.css` imports Barlow Condensed and Montserrat from Google Fonts — both are the families named in the brief, so this is a source substitution, not a typeface substitution. Send TTF/WOFF2 files if the institutional kit requires self-hosting.
2. **Assets are raster, not vector.** The logos, icons, map and grafismos were cropped from the supplied PNGs and background-keyed to transparency. Original SVG/AI/EPS files would give crisper output at large sizes — especially the SUS / Ministério da Saúde lockup.
3. **No logo was invented.** Where a wordmark for the event itself would go, type is set in Barlow Condensed.
4. **Sample content is placeholder.** Dates, session titles and all figures in the UI kit and template are representative examples in the brand's voice, not real programme data.
5. **Intentional additions.** No component library was provided, so the primitive set (`Button` … `SectionHeader`) was authored from the brief's own component rules (sections 10–14). `NavBar`, `SectionHeader`, `Input`, `Select` and `Checkbox` are not described in the brief but are required by the site surface it asks for; they follow its border, radius and colour rules strictly.
