/* @ds-bundle: {"format":4,"namespace":"VigilNciaEpidemiolGicaDTHADesignSystem_039785","components":[{"name":"BrasilNetworkMap","sourcePath":"components/brand/BrasilNetworkMap.jsx"},{"name":"DiagonalGraphic","sourcePath":"components/brand/DiagonalGraphic.jsx"},{"name":"IconCircle","sourcePath":"components/brand/IconCircle.jsx"},{"name":"InstitutionalLogo","sourcePath":"components/brand/InstitutionalLogo.jsx"},{"name":"TitleLockup","sourcePath":"components/brand/TitleLockup.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"BarChart","sourcePath":"components/data/BarChart.jsx"},{"name":"StatFigure","sourcePath":"components/data/StatFigure.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"},{"name":"SectionHeader","sourcePath":"components/navigation/SectionHeader.jsx"}],"sourceHashes":{"components/brand/BrasilNetworkMap.jsx":"69123e82e591","components/brand/DiagonalGraphic.jsx":"5c6c43f961c4","components/brand/IconCircle.jsx":"8a9b45932be2","components/brand/InstitutionalLogo.jsx":"a69bb8634ef4","components/brand/TitleLockup.jsx":"0a7f5c0c323e","components/core/Badge.jsx":"5c09028266fc","components/core/Button.jsx":"773db46518a3","components/core/Card.jsx":"3e37d99425be","components/core/Divider.jsx":"fdd2e27770cf","components/data/BarChart.jsx":"b03d19f14c0c","components/data/StatFigure.jsx":"b9ddd10190d2","components/forms/Checkbox.jsx":"889e08008295","components/forms/Input.jsx":"0eec022530a4","components/forms/Select.jsx":"0beeaf227e20","components/navigation/NavBar.jsx":"972cfd571871","components/navigation/SectionHeader.jsx":"5fa7bcf51e27","ui_kits/site-reuniao/Eixos.jsx":"b521ebd92e58","ui_kits/site-reuniao/Footer.jsx":"644fb24acf60","ui_kits/site-reuniao/Hero.jsx":"e1733ac6967b","ui_kits/site-reuniao/Inscricao.jsx":"7850e0c8427a","ui_kits/site-reuniao/Programacao.jsx":"00a31c6a5f18"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.VigilNciaEpidemiolGicaDTHADesignSystem_039785 = window.VigilNciaEpidemiolGicaDTHADesignSystem_039785 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/BrasilNetworkMap.jsx
try { (() => {
function BrasilNetworkMap({
  width = 440,
  assetBase = 'assets',
  variant = 'standard',
  animate = true,
  style
}) {
  const src = variant === 'large' ? 'mapa-brasil-rede-grande.png' : 'mapa-brasil-rede.png';
  const ratio = variant === 'large' ? 670 / 620 : 500 / 460;
  return /*#__PURE__*/React.createElement("img", {
    src: assetBase + '/' + src,
    alt: "Mapa do Brasil em rede de vigil\xE2ncia epidemiol\xF3gica",
    style: {
      display: 'block',
      width,
      height: Math.round(width / ratio),
      animation: animate ? 'rve-map-in var(--duration-map) var(--ease-standard) both' : 'none',
      ...style
    }
  });
}
Object.assign(__ds_scope, { BrasilNetworkMap });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/BrasilNetworkMap.jsx", error: String((e && e.message) || e) }); }

// components/brand/DiagonalGraphic.jsx
try { (() => {
const FILES = {
  descending: 'grafismo-diagonais-descendente.png',
  ascending: 'grafismo-diagonais-ascendente.png',
  waves: 'grafismo-ondas-horizontal.png'
};
function DiagonalGraphic({
  variant = 'descending',
  assetBase = 'assets',
  position = 'bottom-left',
  opacity = .85,
  height = '60%',
  parallax = 0,
  style
}) {
  const pos = {
    'bottom-left': {
      bottom: 0,
      left: 0
    },
    'bottom-right': {
      bottom: 0,
      right: 0
    },
    'top-left': {
      top: 0,
      left: 0
    },
    'bottom-full': {
      bottom: 0,
      left: 0,
      right: 0,
      width: '100%'
    }
  };
  return /*#__PURE__*/React.createElement("img", {
    src: assetBase + '/' + FILES[variant],
    alt: "",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      pointerEvents: 'none',
      opacity,
      height,
      transform: 'translate(' + parallax + 'px,' + parallax + 'px)',
      transition: 'transform var(--duration-slow) var(--ease-standard)',
      ...pos[position],
      ...style
    }
  });
}
Object.assign(__ds_scope, { DiagonalGraphic });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/DiagonalGraphic.jsx", error: String((e && e.message) || e) }); }

// components/brand/IconCircle.jsx
try { (() => {
const SRC = {
  agua: 'icone-gota-agua.png',
  alimentar: 'icone-garfo-faca.png',
  ciencia: 'icone-microscopio.png'
};
function IconCircle({
  symbol = 'agua',
  size = 96,
  assetBase = 'assets',
  delay = 0,
  animate = true,
  label,
  style
}) {
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 'var(--space-2)',
      animation: animate ? 'rve-emerge var(--duration-normal) var(--ease-standard) both' : 'none',
      animationDelay: delay + 'ms',
      ...style
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: assetBase + '/' + SRC[symbol],
    alt: label || symbol,
    width: size,
    height: size,
    style: {
      display: 'block',
      width: size,
      height: size
    }
  }), label ? /*#__PURE__*/React.createElement("figcaption", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--font-weight-medium)',
      letterSpacing: 'var(--tracking-caption)',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { IconCircle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/IconCircle.jsx", error: String((e && e.message) || e) }); }

// components/brand/InstitutionalLogo.jsx
try { (() => {
const FILES = {
  horizontal: {
    src: 'logo-sus-ms-brasil-horizontal.png',
    ratio: 480 / 100
  },
  vertical: {
    src: 'logo-sus-ms-brasil-vertical.png',
    ratio: 300 / 390
  }
};
function InstitutionalLogo({
  orientation = 'horizontal',
  width,
  assetBase = 'assets',
  clearspace = 32,
  style
}) {
  const f = FILES[orientation];
  const w = width || (orientation === 'horizontal' ? 360 : 200);
  return /*#__PURE__*/React.createElement("img", {
    src: assetBase + '/' + f.src,
    alt: "SUS \xB7 Minist\xE9rio da Sa\xFAde \xB7 Governo Federal do Brasil",
    style: {
      display: 'block',
      width: w,
      height: Math.round(w / f.ratio),
      padding: clearspace,
      boxSizing: 'content-box',
      ...style
    }
  });
}
Object.assign(__ds_scope, { InstitutionalLogo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/InstitutionalLogo.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function Badge({
  variant = 'green',
  children,
  style
}) {
  const variants = {
    green: {
      background: 'var(--color-green-dark)',
      color: 'var(--color-white)'
    },
    cyan: {
      background: 'var(--color-cyan)',
      color: 'var(--color-primary-dark)'
    },
    turquoise: {
      background: 'var(--color-turquoise)',
      color: 'var(--color-white)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--color-teal)',
      border: 'var(--border-thin) solid var(--line-card)'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--font-weight-medium)',
      letterSpacing: 'var(--tracking-caption)',
      textTransform: 'uppercase',
      padding: '6px 14px',
      borderRadius: 'var(--radius-sm)',
      ...variants[variant],
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/brand/TitleLockup.jsx
try { (() => {
function TitleLockup({
  tag,
  lines = [],
  subtitle,
  keywords = [],
  align = 'left',
  size = 'lg',
  animate = true,
  style
}) {
  const sizes = {
    xl: 'var(--text-display-xl)',
    lg: 'var(--text-display-lg)',
    md: 'var(--text-display-md)'
  };
  const leads = {
    xl: 'var(--leading-display-xl)',
    lg: 'var(--leading-display-lg)',
    md: 'var(--leading-display-md)'
  };
  const anim = animate ? {
    animation: 'rve-rise var(--duration-title) var(--ease-standard) both'
  } : {};
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align,
      gap: 'var(--space-3)',
      ...style
    }
  }, tag ? /*#__PURE__*/React.createElement("div", {
    style: {
      ...anim
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: "green"
  }, tag)) : null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--font-weight-extrabold)',
      fontSize: sizes[size],
      lineHeight: leads[size],
      letterSpacing: 'var(--tracking-display)',
      textTransform: 'uppercase',
      color: 'var(--text-primary)',
      ...anim,
      animationDelay: '60ms'
    }
  }, lines.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, l))), subtitle ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 'var(--font-weight-regular)',
      fontSize: 'var(--text-heading-md)',
      letterSpacing: 'var(--tracking-subtitle)',
      textTransform: 'uppercase',
      color: 'var(--text-primary)',
      ...anim,
      animationDelay: '120ms'
    }
  }, subtitle) : null, keywords.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center',
      fontFamily: 'var(--font-body)',
      fontWeight: 'var(--font-weight-bold)',
      fontSize: 'var(--text-heading-md)',
      letterSpacing: 'var(--tracking-subtitle)',
      textTransform: 'uppercase',
      ...anim,
      animationDelay: '180ms'
    }
  }, keywords.map((k, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: k
  }, i > 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontWeight: 'var(--font-weight-light)'
    }
  }, "|") : null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: i % 2 === 0 ? 'var(--color-cyan)' : 'var(--color-turquoise)'
    }
  }, k)))) : null);
}
Object.assign(__ds_scope, { TitleLockup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/TitleLockup.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const base = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 'var(--space-2)',
  fontFamily: 'var(--font-body)',
  fontWeight: 'var(--font-weight-semibold)',
  lineHeight: 1,
  letterSpacing: '.02em',
  borderRadius: 'var(--radius-sm)',
  cursor: 'pointer',
  textDecoration: 'none',
  boxShadow: 'var(--shadow-none)',
  transition: 'background var(--duration-fast) var(--ease-standard),border-color var(--duration-fast) var(--ease-standard),color var(--duration-fast) var(--ease-standard)'
};
const sizes = {
  sm: {
    padding: '8px 16px',
    fontSize: 'var(--text-body-sm)'
  },
  md: {
    padding: '12px 24px',
    fontSize: 'var(--text-body)'
  },
  lg: {
    padding: '16px 32px',
    fontSize: 'var(--text-body-lg)'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  as = 'button',
  href,
  onClick,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const variants = {
    primary: {
      background: hover ? 'var(--color-green-dark)' : 'var(--color-turquoise)',
      color: 'var(--color-white)',
      border: 'var(--border-thin) solid transparent'
    },
    secondary: {
      background: hover ? 'rgba(78,181,181,.12)' : 'transparent',
      color: 'var(--color-white)',
      border: 'var(--border-thin) solid var(--color-teal)'
    },
    ghost: {
      background: 'transparent',
      color: hover ? 'var(--color-teal)' : 'var(--color-cyan)',
      border: 'var(--border-thin) solid transparent',
      padding: size === 'sm' ? '8px 4px' : '12px 4px'
    }
  };
  const Tag = as === 'a' ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: as === 'a' ? href : undefined,
    onClick: disabled ? undefined : onClick,
    disabled: Tag === 'button' ? disabled : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...sizes[size],
      ...variants[variant],
      width: fullWidth ? '100%' : 'auto',
      opacity: disabled ? .42 : 1,
      pointerEvents: disabled ? 'none' : 'auto',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  accent = 'none',
  interactive = false,
  padding = 'md',
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const pads = {
    sm: 'var(--space-4)',
    md: 'var(--space-5)',
    lg: 'var(--space-6)'
  };
  const accents = {
    none: {},
    left: {
      borderLeft: 'var(--border-strong) solid var(--color-cyan)'
    },
    top: {
      borderTop: 'var(--border-strong) solid var(--color-turquoise)'
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: interactive && hover ? 'var(--surface-card-hover)' : 'var(--surface-card)',
      border: 'var(--border-thin) solid var(--line-card)',
      borderRadius: 'var(--radius-md)',
      padding: pads[padding],
      boxShadow: 'var(--shadow-none)',
      transition: 'background var(--duration-fast) var(--ease-standard)',
      ...accents[accent],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function Divider({
  tone = 'subtle',
  thickness = 'thin',
  width = '100%',
  style
}) {
  const tones = {
    subtle: 'var(--line-subtle)',
    structure: 'var(--line-structure)',
    accent: 'var(--color-cyan)'
  };
  const t = {
    thin: 'var(--border-thin)',
    medium: 'var(--border-medium)',
    strong: 'var(--border-strong)'
  };
  return /*#__PURE__*/React.createElement("hr", {
    style: {
      border: 0,
      borderTop: t[thickness] + ' solid ' + tones[tone],
      width,
      margin: 0,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/data/BarChart.jsx
try { (() => {
function BarChart({
  data = [],
  max,
  unit = '',
  height = 220,
  accent = 'cyan',
  showGrid = true,
  style
}) {
  const colors = {
    cyan: 'var(--data-1)',
    turquoise: 'var(--data-2)',
    teal: 'var(--data-3)',
    green: 'var(--data-4)'
  };
  const top = max || Math.max(...data.map(d => d.value), 1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height,
      display: 'grid',
      gridTemplateColumns: 'repeat(' + data.length + ',1fr)',
      gap: 'var(--space-3)',
      alignItems: 'end',
      borderBottom: 'var(--border-thin) solid var(--data-grid)'
    }
  }, showGrid ? [0.25, 0.5, 0.75, 1].map(f => /*#__PURE__*/React.createElement("div", {
    key: f,
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: f * 100 + '%',
      borderTop: 'var(--border-thin) solid var(--data-grid)',
      opacity: .5
    }
  })) : null, data.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.label,
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--font-weight-bold)',
      fontSize: 'var(--text-heading-md)',
      color: 'var(--text-primary)',
      lineHeight: 1
    }
  }, d.value, unit), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: d.value / top * 100 + '%',
      background: d.accent ? colors[d.accent] : colors[accent],
      borderRadius: 'var(--radius-sm) var(--radius-sm) 0 0',
      transition: 'height var(--duration-slow) var(--ease-standard)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(' + data.length + ',1fr)',
      gap: 'var(--space-3)',
      marginTop: 'var(--space-2)'
    }
  }, data.map(d => /*#__PURE__*/React.createElement("span", {
    key: d.label,
    style: {
      textAlign: 'center',
      fontSize: 'var(--text-caption)',
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, d.label))));
}
Object.assign(__ds_scope, { BarChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/BarChart.jsx", error: String((e && e.message) || e) }); }

// components/data/StatFigure.jsx
try { (() => {
function StatFigure({
  value,
  unit,
  label,
  accent = 'cyan',
  size = 'lg',
  style
}) {
  const colors = {
    cyan: 'var(--color-cyan)',
    turquoise: 'var(--color-turquoise)',
    teal: 'var(--color-teal)',
    white: 'var(--color-white)'
  };
  const sizes = {
    lg: 'var(--text-display-xl)',
    md: 'var(--text-display-lg)',
    sm: 'var(--text-display-md)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-1)',
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--font-weight-bold)',
      fontSize: sizes[size],
      lineHeight: .9,
      letterSpacing: 'var(--tracking-display)',
      color: colors[accent]
    }
  }, /*#__PURE__*/React.createElement("span", null, value), unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 'var(--font-weight-semibold)',
      fontSize: 'var(--text-body-lg)',
      letterSpacing: 0
    }
  }, unit) : null), label ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)',
      maxWidth: '32ch'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { StatFigure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatFigure.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  onChange,
  disabled = false,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-primary)',
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? .42 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 auto',
      width: 18,
      height: 18,
      marginTop: 2,
      borderRadius: 'var(--radius-sm)',
      border: 'var(--border-thin) solid ' + (checked ? 'var(--color-turquoise)' : 'var(--line-card)'),
      background: checked ? 'var(--color-turquoise)' : 'transparent',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background var(--duration-fast) var(--ease-standard)'
    }
  }, checked ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 5,
      borderLeft: '2px solid #fff',
      borderBottom: '2px solid #fff',
      transform: 'rotate(-45deg) translateY(-1px)'
    }
  }) : null), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: !!checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  type = 'text',
  as = 'input',
  rows = 4,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || 'in-' + (label || 'field').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const Tag = as === 'textarea' ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--font-weight-semibold)',
      letterSpacing: 'var(--tracking-caption)',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, label) : null, /*#__PURE__*/React.createElement(Tag, _extends({
    id: fid,
    type: Tag === 'input' ? type : undefined,
    rows: Tag === 'textarea' ? rows : undefined,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      background: 'rgba(255,255,255,.04)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body)',
      padding: '12px 14px',
      borderRadius: 'var(--radius-sm)',
      border: 'var(--border-thin) solid ' + (error ? 'var(--color-cyan)' : focus ? 'var(--color-teal)' : 'var(--line-card)'),
      outline: 'none',
      width: '100%',
      boxSizing: 'border-box',
      resize: as === 'textarea' ? 'vertical' : undefined
    }
  }, rest)), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--color-cyan)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  hint,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || 'sel-' + (label || 'field').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--font-weight-semibold)',
      letterSpacing: 'var(--tracking-caption)',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("select", _extends({
    id: fid,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      background: 'rgba(255,255,255,.04)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body)',
      padding: '12px 14px',
      borderRadius: 'var(--radius-sm)',
      border: 'var(--border-thin) solid ' + (focus ? 'var(--color-teal)' : 'var(--line-card)'),
      outline: 'none',
      width: '100%'
    }
  }, rest), options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v,
      style: {
        color: '#143353'
      }
    }, l);
  })), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar({
  items = [],
  active,
  onNavigate,
  cta,
  assetBase = 'assets',
  style
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-6)',
      padding: 'var(--space-3) var(--page-padding)',
      background: 'var(--color-primary-dark)',
      borderBottom: 'var(--border-thin) solid var(--line-subtle)',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.InstitutionalLogo, {
    orientation: "horizontal",
    width: 210,
    clearspace: 0,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, items.map(it => {
    const on = it === active;
    return /*#__PURE__*/React.createElement("a", {
      key: it,
      href: '#' + it,
      onClick: e => {
        e.preventDefault();
        onNavigate && onNavigate(it);
      },
      style: {
        fontSize: 'var(--text-body-sm)',
        fontWeight: on ? 'var(--font-weight-semibold)' : 'var(--font-weight-medium)',
        letterSpacing: '.04em',
        textTransform: 'uppercase',
        color: on ? 'var(--color-cyan)' : 'var(--color-white)',
        paddingBottom: 4,
        borderBottom: 'var(--border-medium) solid ' + (on ? 'var(--color-cyan)' : 'transparent')
      }
    }, it);
  }), cta ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    onClick: cta.onClick
  }, cta.label) : null));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SectionHeader.jsx
try { (() => {
function SectionHeader({
  eyebrow,
  title,
  description,
  align = 'left',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align,
      maxWidth: align === 'center' ? '62ch' : '72ch',
      ...style
    }
  }, eyebrow ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--font-weight-semibold)',
      letterSpacing: 'var(--tracking-caption)',
      textTransform: 'uppercase',
      color: 'var(--color-cyan)'
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--font-weight-bold)',
      fontSize: 'var(--text-heading-xl)',
      lineHeight: 'var(--leading-heading)',
      letterSpacing: 'var(--tracking-display)',
      textTransform: 'uppercase',
      color: 'var(--text-primary)'
    }
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--text-body)',
      color: 'var(--text-secondary)'
    }
  }, description) : null);
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-reuniao/Eixos.jsx
try { (() => {
const {
  SectionHeader,
  Card,
  IconCircle,
  StatFigure,
  BarChart,
  DiagonalGraphic
} = window.VigilNciaEpidemiolGicaDTHADesignSystem_039785;
const EIXOS = [{
  symbol: 'agua',
  t: 'Transmissão hídrica',
  d: 'Vigilância da qualidade da água para consumo humano e resposta a surtos de veiculação hídrica.'
}, {
  symbol: 'alimentar',
  t: 'Transmissão alimentar',
  d: 'Investigação de surtos de doenças transmitidas por alimentos e articulação com a vigilância sanitária.'
}, {
  symbol: 'ciencia',
  t: 'Rede laboratorial',
  d: 'Diagnóstico laboratorial, fluxos de amostras e oportunidade dos resultados na rede pública.'
}];
function Eixos({
  assetBase
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "eixos",
    style: {
      position: 'relative',
      overflow: 'hidden',
      padding: 'var(--space-10) var(--page-padding)',
      background: 'var(--color-primary-dark)'
    }
  }, /*#__PURE__*/React.createElement(DiagonalGraphic, {
    variant: "ascending",
    position: "bottom-right",
    height: "70%",
    opacity: .55,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Eixos tem\xE1ticos",
    title: "O que ser\xE1 discutido"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-4)'
    }
  }, EIXOS.map((e, i) => /*#__PURE__*/React.createElement(Card, {
    key: e.t,
    accent: "top",
    padding: "md",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(IconCircle, {
    symbol: e.symbol,
    size: 64,
    delay: i * 100,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-heading-lg)',
      textTransform: 'uppercase',
      lineHeight: 1.05
    }
  }, e.t), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)'
    }
  }, e.d)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '300px minmax(0,1fr)',
      gap: 'var(--space-7)',
      alignItems: 'center',
      marginTop: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(StatFigure, {
    value: "42,9%",
    size: "md",
    accent: "cyan",
    label: "dos surtos com ve\xEDculo de transmiss\xE3o identificado est\xE3o associados \xE0 \xE1gua"
  }), /*#__PURE__*/React.createElement(StatFigure, {
    value: "1.284",
    unit: "surtos",
    size: "sm",
    accent: "turquoise",
    label: "notificados pelas unidades federativas no per\xEDodo"
  })), /*#__PURE__*/React.createElement(BarChart, {
    height: 200,
    data: [{
      label: '2021',
      value: 612
    }, {
      label: '2022',
      value: 704
    }, {
      label: '2023',
      value: 889,
      accent: 'turquoise'
    }, {
      label: '2024',
      value: 958,
      accent: 'teal'
    }, {
      label: '2025',
      value: 1284,
      accent: 'green'
    }]
  }))));
}
Object.assign(window, {
  Eixos
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-reuniao/Eixos.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-reuniao/Footer.jsx
try { (() => {
const {
  InstitutionalLogo,
  DiagonalGraphic,
  Divider
} = window.VigilNciaEpidemiolGicaDTHADesignSystem_039785;
function Footer({
  assetBase
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--color-primary-dark)',
      padding: 'var(--space-8) var(--page-padding) var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(DiagonalGraphic, {
    variant: "waves",
    position: "bottom-full",
    height: "auto",
    opacity: .7,
    assetBase: assetBase,
    style: {
      width: '100%',
      height: 'auto'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(InstitutionalLogo, {
    orientation: "vertical",
    width: 190,
    clearspace: 32,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement(Divider, {
    tone: "subtle",
    width: "100%"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)',
      flexWrap: 'wrap',
      justifyContent: 'center',
      fontSize: 'var(--text-caption)',
      letterSpacing: '.06em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Secretaria de Vigil\xE2ncia em Sa\xFAde e Ambiente"), /*#__PURE__*/React.createElement("span", null, "Departamento de Doen\xE7as Transmiss\xEDveis"), /*#__PURE__*/React.createElement("span", null, "Bras\xEDlia \xB7 2026"))));
}
Object.assign(window, {
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-reuniao/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-reuniao/Hero.jsx
try { (() => {
const {
  TitleLockup,
  IconCircle,
  BrasilNetworkMap,
  DiagonalGraphic,
  Button,
  Badge
} = window.VigilNciaEpidemiolGicaDTHADesignSystem_039785;
function Hero({
  onInscrever,
  assetBase
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--color-primary)',
      padding: '96px var(--page-padding) 128px'
    }
  }, /*#__PURE__*/React.createElement(DiagonalGraphic, {
    variant: "descending",
    position: "bottom-left",
    height: "80%",
    opacity: .8,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) 420px',
      gap: 'var(--space-8)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(TitleLockup, {
    tag: "Reuni\xE3o Nacional",
    lines: ['Vigilância', 'Epidemiológica'],
    subtitle: "das doen\xE7as de transmiss\xE3o",
    keywords: ['Hídrica', 'Alimentar'],
    size: "xl"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(IconCircle, {
    symbol: "agua",
    size: 72,
    delay: 0,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement(IconCircle, {
    symbol: "alimentar",
    size: 72,
    delay: 100,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement(IconCircle, {
    symbol: "ciencia",
    size: 72,
    delay: 200,
    assetBase: assetBase
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-4)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: onInscrever
  }, "Inscreva-se"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    as: "a",
    href: "#programacao"
  }, "Ver programa\xE7\xE3o")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "outline"
  }, "Bras\xEDlia \xB7 DF"), /*#__PURE__*/React.createElement(Badge, {
    variant: "outline"
  }, "14 a 16 de outubro de 2026"), /*#__PURE__*/React.createElement(Badge, {
    variant: "outline"
  }, "Presencial e transmitido"))), /*#__PURE__*/React.createElement(BrasilNetworkMap, {
    width: 420,
    assetBase: assetBase
  })));
}
Object.assign(window, {
  Hero
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-reuniao/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-reuniao/Inscricao.jsx
try { (() => {
const {
  SectionHeader,
  Card,
  Input,
  Select,
  Checkbox,
  Button,
  Badge
} = window.VigilNciaEpidemiolGicaDTHADesignSystem_039785;
function Inscricao({
  state,
  setField,
  onSubmit,
  submitted
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "inscricao",
    style: {
      padding: 'var(--space-10) var(--page-padding)',
      background: 'var(--color-primary)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '880px',
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Inscri\xE7\xE3o",
    title: "Participe da reuni\xE3o nacional",
    description: "As vagas presenciais s\xE3o destinadas \xE0s equipes de vigil\xE2ncia epidemiol\xF3gica estaduais, municipais e \xE0 rede laboratorial."
  }), submitted ? /*#__PURE__*/React.createElement(Card, {
    accent: "left",
    padding: "lg",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "green"
  }, "Inscri\xE7\xE3o registrada"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-heading-lg)',
      textTransform: 'uppercase'
    }
  }, "Recebemos seus dados"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)'
    }
  }, "A confirma\xE7\xE3o ser\xE1 enviada para ", state.email || 'seu e-mail institucional', " ap\xF3s a valida\xE7\xE3o pela coordena\xE7\xE3o estadual.")) : /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Nome completo",
    placeholder: "Digite seu nome",
    value: state.nome,
    onChange: e => setField('nome', e.target.value),
    style: {
      gridColumn: '1 / -1'
    }
  }), /*#__PURE__*/React.createElement(Input, {
    label: "E-mail institucional",
    placeholder: "nome@saude.gov.br",
    value: state.email,
    onChange: e => setField('email', e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    label: "UF",
    options: ['Selecione', 'AC', 'AM', 'BA', 'CE', 'DF', 'GO', 'MG', 'PA', 'PE', 'RS', 'SP'],
    value: state.uf,
    onChange: e => setField('uf', e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Esfera de atua\xE7\xE3o",
    options: ['Selecione', 'Estadual', 'Municipal', 'Laboratório de referência', 'Federal'],
    value: state.esfera,
    onChange: e => setField('esfera', e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Eixo de interesse",
    options: ['Selecione', 'Transmissão hídrica', 'Transmissão alimentar', 'Rede laboratorial'],
    value: state.eixo,
    onChange: e => setField('eixo', e.target.value)
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Experi\xEAncia com investiga\xE7\xE3o de surtos",
    as: "textarea",
    rows: 4,
    placeholder: "Descreva brevemente",
    value: state.exp,
    onChange: e => setField('exp', e.target.value),
    hint: "Opcional \xB7 at\xE9 800 caracteres.",
    style: {
      gridColumn: '1 / -1'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: state.termo,
    onChange: e => setField('termo', e.target.checked),
    label: "Concordo com o tratamento dos meus dados para fins de organiza\xE7\xE3o da reuni\xE3o nacional."
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    disabled: !state.termo,
    onClick: onSubmit
  }, "Enviar inscri\xE7\xE3o")))));
}
Object.assign(window, {
  Inscricao
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-reuniao/Inscricao.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site-reuniao/Programacao.jsx
try { (() => {
const {
  SectionHeader,
  Card,
  Badge,
  Divider
} = window.VigilNciaEpidemiolGicaDTHADesignSystem_039785;
const DIAS = [{
  dia: 'Dia 01 · 14/10',
  sessoes: [{
    h: '09h00',
    t: 'Abertura institucional',
    s: 'Secretaria de Vigilância em Saúde e Ambiente',
    tag: 'Plenária'
  }, {
    h: '10h30',
    t: 'Panorama nacional das DTHA',
    s: 'Situação epidemiológica 2020–2026',
    tag: 'Painel'
  }, {
    h: '14h00',
    t: 'Investigação de surtos',
    s: 'Oficina com estudos de caso estaduais',
    tag: 'Oficina'
  }]
}, {
  dia: 'Dia 02 · 15/10',
  sessoes: [{
    h: '09h00',
    t: 'Vigilância da qualidade da água',
    s: 'Integração Vigiagua e vigilância epidemiológica',
    tag: 'Painel'
  }, {
    h: '11h00',
    t: 'Rede laboratorial',
    s: 'Diagnóstico, fluxos e oportunidade de resultado',
    tag: 'Painel'
  }, {
    h: '14h00',
    t: 'Sessão de casos',
    s: 'Surtos notificados por estados e municípios',
    tag: 'Casos'
  }]
}, {
  dia: 'Dia 03 · 16/10',
  sessoes: [{
    h: '09h00',
    t: 'Dados, indicadores e resposta',
    s: 'Uso da informação para decisão',
    tag: 'Painel'
  }, {
    h: '11h00',
    t: 'Encaminhamentos e pactuação',
    s: 'Compromissos para o próximo ciclo',
    tag: 'Plenária'
  }]
}];
function Programacao({
  activeDay,
  onSelectDay
}) {
  const dia = DIAS[activeDay] || DIAS[0];
  return /*#__PURE__*/React.createElement("section", {
    id: "programacao",
    style: {
      padding: 'var(--space-10) var(--page-padding)',
      background: 'var(--color-primary)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Programa\xE7\xE3o",
    title: "Tr\xEAs dias de trabalho t\xE9cnico",
    description: "Plen\xE1rias, pain\xE9is, oficinas e sess\xF5es de casos conduzidos por estados, munic\xEDpios, laborat\xF3rios e Minist\xE9rio da Sa\xFAde."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)',
      borderBottom: 'var(--border-thin) solid var(--line-subtle)'
    }
  }, DIAS.map((d, i) => /*#__PURE__*/React.createElement("button", {
    key: d.dia,
    onClick: () => onSelectDay(i),
    style: {
      background: 'none',
      border: 0,
      cursor: 'pointer',
      padding: '0 0 12px',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      fontWeight: i === activeDay ? 600 : 500,
      letterSpacing: '.06em',
      textTransform: 'uppercase',
      color: i === activeDay ? 'var(--color-cyan)' : 'var(--text-secondary)',
      borderBottom: 'var(--border-medium) solid ' + (i === activeDay ? 'var(--color-cyan)' : 'transparent'),
      marginBottom: -1
    }
  }, d.dia))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, dia.sessoes.map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.t,
    accent: "left",
    padding: "md",
    interactive: true,
    style: {
      display: 'grid',
      gridTemplateColumns: '96px minmax(0,1fr) auto',
      gap: 'var(--space-4)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-heading-md)',
      color: 'var(--color-teal)'
    }
  }, s.h), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-heading-md)',
      textTransform: 'uppercase',
      letterSpacing: '-.01em',
      lineHeight: 1.1
    }
  }, s.t), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)'
    }
  }, s.s)), /*#__PURE__*/React.createElement(Badge, {
    variant: "outline"
  }, s.tag)))), /*#__PURE__*/React.createElement(Divider, {
    tone: "structure"
  })));
}
Object.assign(window, {
  Programacao
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site-reuniao/Programacao.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BrasilNetworkMap = __ds_scope.BrasilNetworkMap;

__ds_ns.DiagonalGraphic = __ds_scope.DiagonalGraphic;

__ds_ns.IconCircle = __ds_scope.IconCircle;

__ds_ns.InstitutionalLogo = __ds_scope.InstitutionalLogo;

__ds_ns.TitleLockup = __ds_scope.TitleLockup;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.BarChart = __ds_scope.BarChart;

__ds_ns.StatFigure = __ds_scope.StatFigure;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.NavBar = __ds_scope.NavBar;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

})();
